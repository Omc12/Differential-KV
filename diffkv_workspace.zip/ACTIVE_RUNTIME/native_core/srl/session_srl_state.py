"""
native_core/srl/session_srl_state.py

Per-session SRL state: holds all routing indexes and running stats.
One instance per session, attached to KVRuntimeManager._session_srl[session_id].

Memory footprint for a 25K-token session (781 blocks):
  desc_matrix:   781 × 64 × 2 B  =  100 KB  (GPU)
  chunk_graph:   781 × 8  × 4 B  =   25 KB  (CPU/GPU)
  inverted_index: ~5000 terms × avg 12 blocks × 4 B = 240 KB  (CPU)
  ordered_slot_ids: 781 × 4 B    =    3 KB  (CPU)
  Total: ~368 KB  (vs ~400 MB compressed KV pool → <0.1% overhead)
"""

from __future__ import annotations
import math
from dataclasses import dataclass, field
from typing import List, Dict, Optional

import torch

from native_core.srl.semantic_index import SemanticIndex
from native_core.srl.chunk_graph import ChunkGraph
from native_core.srl.inverted_index import InvertedTokenIndex


@dataclass
class SessionSRLState:
    """All routing indexes for one session."""

    semantic_index:     SemanticIndex
    chunk_graph:        ChunkGraph
    inverted_index:     InvertedTokenIndex

    # Pool slot IDs in chronological order (one per block, layer-0 reference)
    ordered_slot_ids:   List[int]

    # Pool slot IDs that are always included (block 0, special-token blocks)
    sink_blocks:        List[int]

    # Adaptive-K running state
    recent_miss_rate:   float = 0.0
    k_multiplier:       float = 1.0
    call_count:         int   = 0

    # Rolling window of recently generated token IDs for lexical lookup
    recent_generated_tokens: List[int] = field(default_factory=list)

    ordered_anchor_idxs: List[int] = field(default_factory=list)
    cached_len: int = 0

    # Structured Attention Segmenting (SAS) fields
    segment_ids: Dict[int, int] = field(default_factory=dict)
    current_query_segment_id: int = 0
    concept_tok_1: int = -1
    concept_tok_2: int = -1

    # Eagle-Guided Query Anchoring & Dynamic Routing (EQA-DR) fields
    prompt_eagle_scores: Optional[torch.Tensor] = None
    prompt_anchors: List[int] = field(default_factory=list)
    recent_decode_keys: List[torch.Tensor] = field(default_factory=list)
    generated_token_slots: List[int] = field(default_factory=list)
    dynamic_anchors: List[int] = field(default_factory=list)

    # Per-decode-step cached slot selection (shared across all 28 layers)
    # Set by layer 0, consumed by layers 1–27
    current_step_slots: Optional[torch.Tensor] = None
    current_step_count: int = 0   # decode step counter for validation
    last_prefill_q: Optional[torch.Tensor] = None
    current_step_factual_tokens: set = field(default_factory=set)
    current_step_factual_sequences: List[List[int]] = field(default_factory=list)
    current_step_max_similarity: float = 0.0
    vsl_active_candidates: List[List[int]] = field(default_factory=list)
    vsl_consecutive_helpers: int = 0
    # First decode-step query vector stored as an anchor.
    # Used to blend with current query during factual store lookups so that
    # semantic drift (query vector accumulating generated text) cannot pull
    # retrieval away from the original question topic.
    factual_anchor_q: Optional[torch.Tensor] = None

    # Entity-subgraph tracking for relationship binding.
    # current_entity_id: document position (start_idx) of the prime entry for
    #   the entity currently being generated about. -1 = no context established.
    #   Persists across decode steps within one response; reset at generation start.
    # current_step_sequence_entity_ids: parallel to current_step_factual_sequences;
    #   entity_id (prime start_idx) for each sequence. -1 = unknown.
    # current_step_sequence_is_prime: parallel list; True if the sequence is a prime entry.
    current_entity_id: int = -1
    # Dual-entity mode for comparison questions (e.g., "Compare EP2 and EP3").
    # When active, both entities' factual sequences are available for generation
    # but cross-entity contamination is prevented via strict VSL filtering.
    dual_entity_mode: bool = False
    dual_entity_ids: List[int] = field(default_factory=list)  # [entity_id_1, entity_id_2]
    # RC5 — explicit comparison mode: when ≥2 entities are being compared we do
    # NOT let them interleave; we lock generation to one entity at a time and
    # advance only once it has been substantively covered.  comparison_entities
    # is the ordered block sequence; comparison_active_idx the current block;
    # comparison_covered the entities already produced.
    comparison_entities: List[int] = field(default_factory=list)
    comparison_active_idx: int = 0
    comparison_covered: set = field(default_factory=set)
    current_step_sequence_entity_ids: List[int] = field(default_factory=list)
    current_step_sequence_is_prime: List[bool] = field(default_factory=list)
    # current_step_sequence_prefixes: parallel list; the source tokens preceding
    # each sequence's span (RC2 quote-grounded connectives). [] for triples.
    current_step_sequence_prefixes: List[List[int]] = field(default_factory=list)

    # Per-layer ordered slots (all layers share pool slots → same list for all)
    # Maps layer_idx → ordered list of pool slot IDs (currently identical for every layer)
    layer_slot_ids: Dict[int, List[int]] = field(default_factory=dict)

    # Dynamic Node Reinforcement Strength
    slot_activation_strength: Dict[int, float] = field(default_factory=dict)

    # ── Config (all overridable via SRL_CONFIG or env vars) ──────────────────
    k_min:             int   = 20
    k_max:             int   = 200
    k_semantic_frac:   float = 0.50
    k_lexical_frac:    float = 0.15
    k_graph_frac:      float = 0.15
    k_recency_frac:    float = 0.20
    routing_threshold: int   = 2
    overlap_threshold: float = 0.15
    graph_hop_decay:   float = 0.5
    srl_age_penalty:   float = 0.01

    def n_active_blocks(self) -> int:
        """Number of compressed blocks in this session."""
        return len(self.ordered_slot_ids)

    def update_generated_tokens(self, token_id: int, maxlen: int = 64) -> None:
        """Append a newly generated token ID to the rolling window."""
        self.recent_generated_tokens.append(token_id)
        if len(self.recent_generated_tokens) > maxlen:
            self.recent_generated_tokens = self.recent_generated_tokens[-maxlen:]

    def update_miss_rate(self, attention_weights_k: torch.Tensor) -> None:
        """
        Update the exponential moving average miss-rate signal.

        A flat attention distribution over the selected blocks (max_weight ≈ 1/K)
        suggests the truly-relevant block wasn't selected → high miss signal.
        A peaked distribution (one block dominated) → low miss signal.
        """
        K = attention_weights_k.shape[0]
        if K == 0:
            return
        max_w = float(attention_weights_k.max())
        expected_max = 1.0 / K
        denom = (1.0 - expected_max) + 1e-8
        miss_signal = max(0.0, min(1.0, 1.0 - (max_w - expected_max) / denom))

        alpha = 0.05  # EMA smoothing
        self.recent_miss_rate = (1.0 - alpha) * self.recent_miss_rate + alpha * miss_signal

        # Boost K multiplier when miss rate is high
        if self.recent_miss_rate > 0.4:
            self.k_multiplier = min(self.k_multiplier * 1.2, 3.0)
        else:
            self.k_multiplier = max(self.k_multiplier * 0.99, 1.0)

    def expand_neighborhood(self, seed_slots: Set[int]) -> Set[int]:
        expanded = set(seed_slots)
        if self.chunk_graph is None or self.semantic_index is None:
            return expanded
            
        slot_to_row = {int(slot): idx for idx, slot in enumerate(self.semantic_index.slot_ids.tolist())}
        neighbors_tensor = self.chunk_graph.neighbors
        
        for slot in list(seed_slots):
            if slot in slot_to_row:
                row_idx = slot_to_row[slot]
                if row_idx < neighbors_tensor.shape[0]:
                    nb_rows = neighbors_tensor[row_idx].tolist()
                    for nb_row in nb_rows:
                        if nb_row >= 0 and nb_row < self.semantic_index.slot_ids.shape[0]:
                            nb_slot = int(self.semantic_index.slot_ids[nb_row].item())
                            expanded.add(nb_slot)
        return expanded

    def update_query_segment(self, token_id: int) -> None:
        # Look at the last 12 generated tokens
        recent_window = self.recent_generated_tokens[-12:]
        seg1_score = 0.0
        seg2_score = 0.0
        
        for tid in recent_window:
            if self.inverted_index is not None and tid in self.inverted_index.occurrences:
                occs = self.inverted_index.occurrences[tid]
                total_cnt = len(occs)
                if total_cnt > 0:
                    seg1_cnt = sum(1 for slot, _, _ in occs if self.segment_ids.get(slot, 0) == 1)
                    seg2_cnt = sum(1 for slot, _, _ in occs if self.segment_ids.get(slot, 0) == 2)
                    idf_val = self.inverted_index.idf.get(tid, 1.0)
                    seg1_score += (seg1_cnt / total_cnt) * idf_val
                    seg2_score += (seg2_cnt / total_cnt) * idf_val
                        
        if seg1_score > seg2_score + 1.0:
            self.current_query_segment_id = 1
        elif seg2_score > seg1_score + 1.0:
            self.current_query_segment_id = 2
        else:
            self.current_query_segment_id = 0

    def update_dynamic_anchors(self, stop_token_ids: Set[int]) -> None:
        L_g = len(self.recent_decode_keys)
        if L_g < 2 or L_g % 4 != 0:
            return
            
        keys_tensor = torch.stack(self.recent_decode_keys) # [L_g, head_dim]
        sim = torch.matmul(keys_tensor, keys_tensor.T) / math.sqrt(keys_tensor.shape[1])
        
        # Apply causal mask
        mask = torch.triu(torch.ones(L_g, L_g, device=sim.device), diagonal=1).T
        sim = sim.masked_fill(mask == 0, -1e9)
        
        attn = torch.softmax(sim, dim=-1)
        attn = torch.nan_to_num(attn, nan=0.0)
        
        R_gen = attn.sum(dim=0).cpu().tolist()
        
        self.dynamic_anchors = []
        for i in range(L_g):
            if R_gen[i] > 1.5:
                if i < len(self.recent_generated_tokens):
                    tid = self.recent_generated_tokens[i]
                    if tid not in stop_token_ids:
                        if i < len(self.generated_token_slots):
                            self.dynamic_anchors.append(self.generated_token_slots[i])

    def setup_sas_and_eqa(self, token_ids: torch.Tensor, stop_token_ids: Set[int], tokenizer: Optional[Any] = None) -> None:
        if self.prompt_eagle_scores is None or token_ids is None:
            return
            
        total_seq_len = token_ids.numel()
        valid_candidates = []
        for i in range(total_seq_len):
            tid = int(token_ids[i].item())
            if tid not in stop_token_ids:
                score = float(self.prompt_eagle_scores[i].item())
                
                # Check for known comparative keywords and boost their scores
                try:
                    word = ""
                    if tokenizer is not None:
                        word = tokenizer.decode([tid]).strip().lower()
                except Exception:
                    pass
                
                # Generalised salience boost (replaces a benchmark-overfit hardcoded
                # physics/math word list — tech-debt #2 / F20). Numeric tokens are
                # universally salient for factual retrieval (codes, IDs, quantities,
                # dates), so boost any all-digit token instead of named domain terms.
                if word and word.isdigit():
                    score += 5.0
                    
                valid_candidates.append((i, score, tid))
                
        # Sort by score descending
        valid_candidates.sort(key=lambda x: x[1], reverse=True)
        self.prompt_anchors = [i for i, _, _ in valid_candidates[:3]]
        
        # Extract unique token IDs
        candidate_tids = []
        seen_tids = set()
        for _, _, tid in valid_candidates:
            if tid not in seen_tids:
                candidate_tids.append(tid)
                seen_tids.add(tid)
                
        # Find concepts with low Jaccard overlap
        def get_slots(tid):
            slots = set()
            if self.inverted_index is not None and tid in self.inverted_index.occurrences:
                for slot, _, _ in self.inverted_index.occurrences[tid]:
                    slots.add(slot)
            return slots
            
        def jaccard(s1, s2):
            if not s1 or not s2:
                return 0.0
            return len(s1 & s2) / len(s1 | s2)
            
        concept_tok_1 = getattr(self, "concept_tok_1", -1)
        concept_tok_2 = getattr(self, "concept_tok_2", -1)
        
        if concept_tok_1 == -1:
            first_idx = -1
            for idx, tid in enumerate(candidate_tids):
                s = get_slots(tid)
                if len(s) >= 1:
                    concept_tok_1 = tid
                    first_idx = idx
                    break
                    
            if first_idx != -1:
                s1 = get_slots(concept_tok_1)
                for j in range(first_idx + 1, len(candidate_tids)):
                    tid2 = candidate_tids[j]
                    s2 = get_slots(tid2)
                    if len(s2) >= 1:
                        j_val = jaccard(s1, s2)
                        if j_val <= 0.2:
                            concept_tok_2 = tid2
                            break
                if concept_tok_2 == -1:
                    # Fallback to minimum Jaccard overlap
                    min_j = 1.0
                    best_tid2 = -1
                    for j in range(first_idx + 1, len(candidate_tids)):
                        tid2 = candidate_tids[j]
                        s2 = get_slots(tid2)
                        if len(s2) >= 1:
                            j_val = jaccard(s1, s2)
                            if j_val < min_j:
                                min_j = j_val
                                best_tid2 = tid2
                    concept_tok_2 = best_tid2
                
        self.concept_tok_1 = concept_tok_1
        self.concept_tok_2 = concept_tok_2
        
        # Map segments
        existing_segs = getattr(self, "segment_ids", {})
        self.segment_ids = {slot: existing_segs.get(slot, 0) for slot in self.ordered_slot_ids}
        slots_1 = set()
        slots_2 = set()
        
        if self.concept_tok_1 != -1:
            slots_1 = get_slots(self.concept_tok_1)
        if self.concept_tok_2 != -1:
            slots_2 = get_slots(self.concept_tok_2)
            
        # Neighborhood Expansion
        expanded_1 = self.expand_neighborhood(slots_1)
        expanded_2 = self.expand_neighborhood(slots_2)
        
        for slot in self.ordered_slot_ids:
            if slot in existing_segs and existing_segs[slot] != 0:
                continue
            if getattr(self, "cached_len", 0) > 0:
                self.segment_ids[slot] = 0
                continue
            in_1 = slot in expanded_1
            in_2 = slot in expanded_2
            if in_1 and in_2:
                self.segment_ids[slot] = 0
            elif in_1:
                self.segment_ids[slot] = 1
            elif in_2:
                self.segment_ids[slot] = 2
            else:
                self.segment_ids[slot] = 0

    def save_step_state(self, seq_len: int) -> None:
        if not hasattr(self, "_step_history"):
            self._step_history = {}
        self._step_history[seq_len] = {
            "vsl_active_candidates": [list(x) for x in self.vsl_active_candidates] if self.vsl_active_candidates else [],
            "vsl_consecutive_helpers": self.vsl_consecutive_helpers,
            "current_entity_id": self.current_entity_id,
            "current_step_factual_tokens": set(self.current_step_factual_tokens) if self.current_step_factual_tokens else set(),
            "current_step_factual_sequences": [list(x) for x in self.current_step_factual_sequences] if self.current_step_factual_sequences else [],
            "current_step_sequence_entity_ids": list(self.current_step_sequence_entity_ids) if self.current_step_sequence_entity_ids else [],
            "current_step_sequence_is_prime": list(self.current_step_sequence_is_prime) if self.current_step_sequence_is_prime else [],
            "current_step_sequence_prefixes": [list(x) for x in self.current_step_sequence_prefixes] if self.current_step_sequence_prefixes else [],
            "current_step_slots": self.current_step_slots.clone() if self.current_step_slots is not None else None,
            "current_step_max_similarity": self.current_step_max_similarity,
            "dynamic_anchors": list(self.dynamic_anchors) if self.dynamic_anchors else [],
            "generated_token_slots": list(self.generated_token_slots) if self.generated_token_slots else [],
            "recent_generated_tokens": list(self.recent_generated_tokens) if self.recent_generated_tokens else [],
            "recent_decode_keys": list(self.recent_decode_keys) if self.recent_decode_keys else [],
            "current_step_count": self.current_step_count,
        }

    def rollback_to(self, target_len: int, kept_slots: set = None) -> None:
        # 1. Filter slot-related lists if kept_slots is provided
        if kept_slots is not None:
            self.ordered_slot_ids = [slot for slot in self.ordered_slot_ids if slot in kept_slots]
            self.sink_blocks = [slot for slot in self.sink_blocks if slot in kept_slots]
            self.dynamic_anchors = [slot for slot in self.dynamic_anchors if slot in kept_slots]
            self.generated_token_slots = [slot for slot in self.generated_token_slots if slot in kept_slots]

        # 2. Restore decode state from step history
        history = getattr(self, "_step_history", {})
        if target_len in history:
            state = history[target_len]
            self.vsl_active_candidates = [list(x) for x in state["vsl_active_candidates"]]
            self.vsl_consecutive_helpers = state["vsl_consecutive_helpers"]
            self.current_entity_id = state["current_entity_id"]
            self.current_step_factual_tokens = set(state["current_step_factual_tokens"])
            self.current_step_factual_sequences = [list(x) for x in state["current_step_factual_sequences"]]
            self.current_step_sequence_entity_ids = list(state["current_step_sequence_entity_ids"])
            self.current_step_sequence_is_prime = list(state["current_step_sequence_is_prime"])
            self.current_step_sequence_prefixes = [list(x) for x in state["current_step_sequence_prefixes"]]
            self.current_step_slots = state["current_step_slots"].clone() if state["current_step_slots"] is not None else None
            self.current_step_max_similarity = state["current_step_max_similarity"]
            self.dynamic_anchors = [slot for slot in state["dynamic_anchors"] if kept_slots is None or slot in kept_slots]
            self.generated_token_slots = [slot for slot in state["generated_token_slots"] if kept_slots is None or slot in kept_slots]
            self.recent_generated_tokens = list(state["recent_generated_tokens"])
            self.recent_decode_keys = list(state["recent_decode_keys"])
            self.current_step_count = state["current_step_count"]
        else:
            # Fallback: reset all decode-time state variables if target_len is not in history (e.g. before decode started)
            self.vsl_active_candidates = []
            self.vsl_consecutive_helpers = 0
            self.current_entity_id = -1
            self.current_step_factual_tokens = set()
            self.current_step_factual_sequences = []
            self.current_step_sequence_entity_ids = []
            self.current_step_sequence_is_prime = []
            self.current_step_sequence_prefixes = []
            self.current_step_slots = None
            self.current_step_max_similarity = 0.0
            self.dynamic_anchors = []
            self.generated_token_slots = []
            self.recent_generated_tokens = []
            self.recent_decode_keys = []
            self.current_step_count = 0

        # Clean up history entries greater than target_len
        if history:
            stale_keys = [k for k in list(history.keys()) if k > target_len]
            for k in stale_keys:
                history.pop(k, None)

    def commit_turn(self, manager: "KVRuntimeManager", session_id: str) -> None:
        """
        Prune low-salience blocks from the active turn and consolidate the historical graph.
        """
        if manager is None or session_id not in manager.session_blocks:
            return

        # Start of active turn is self.cached_len
        # Any block with b.anchor_idx >= self.cached_len is active
        keep_slots = set(self.sink_blocks)

        # Add cluster centers and landmarks
        if self.chunk_graph is not None:
            if getattr(self.chunk_graph, "cluster_centers_tensor", None) is not None:
                keep_slots.update(self.chunk_graph.cluster_centers_tensor.tolist())
            if getattr(self.chunk_graph, "parent_landmarks", None) is not None:
                keep_slots.update(self.chunk_graph.parent_landmarks.tolist())

        # Add factual exact store slots
        fact_store = manager._factual_stores.get(session_id)
        if fact_store is not None and hasattr(fact_store, "entries"):
            for entry in fact_store.entries:
                if hasattr(entry, "slot_ids"):
                    keep_slots.update(entry.slot_ids)

        # Filter active blocks by high IDF (salience)
        # Scan active blocks (anchor_idx >= cached_len)
        active_slots = set()
        blocks_layer0 = manager.session_blocks[session_id].get(0, [])
        for b in blocks_layer0:
            if getattr(b, "pool_idx", None) is not None and b.anchor_idx >= self.cached_len:
                active_slots.add(b.pool_idx)
                # Check for high IDF tokens (IDF >= 2.5)
                if self.inverted_index is not None and getattr(self.inverted_index, "idf", None) is not None:
                    if getattr(b, "token_indices", None):
                        if any(self.inverted_index.idf.get(tok, 1.0) >= 2.5 for tok in b.token_indices):
                            keep_slots.add(b.pool_idx)

        # Prune blocks that are NOT in keep_slots and were active in this turn
        pruned_slots = active_slots - keep_slots
        if not pruned_slots:
            if manager._session_token_ids.get(session_id) is not None:
                self.cached_len = manager._session_token_ids[session_id].numel()
            return

        # Free blocks from native pool
        if getattr(manager, "native_pool", None) is not None:
            for slot in pruned_slots:
                manager.native_pool.free_block(slot)
                # Clear from slot reinforcement dict
                self.slot_activation_strength.pop(slot, None)

        # Remove pruned blocks from manager.session_blocks
        num_layers = manager.num_layers
        for layer_idx in range(num_layers):
            if session_id in manager.session_blocks:
                blocks = manager.session_blocks[session_id][layer_idx]
                manager.session_blocks[session_id][layer_idx] = [
                    b for b in blocks if getattr(b, "pool_idx", None) not in pruned_slots
                ]
            if manager._streaming_mgr is not None and session_id in manager._streaming_mgr.session_blocks:
                blocks = manager._streaming_mgr.session_blocks[session_id][layer_idx]
                manager._streaming_mgr.session_blocks[session_id][layer_idx] = [
                    b for b in blocks if getattr(b, "pool_idx", None) not in pruned_slots
                ]

        # Update cached_len to current sequence length
        if manager._session_token_ids.get(session_id) is not None:
            self.cached_len = manager._session_token_ids[session_id].numel()

        # Re-run finalize_srl_index to clean and update the index
        manager.finalize_srl_index(session_id, cached_len=self.cached_len)


